/*
 * Mohammadreza shahbazi jalali
 * 
 * professor : Mani Heravi
 * Class : Thursday 
 * project 4
 * Graph
 * 
 */
public class Graph {

	LinkList[] adjList;
	int size;
	boolean[] visitedV;

	// private int nVerts;
	public Graph(int size) {
		this.size = size;
		adjList = new LinkList[size];
		for (int i = 0; i < size; i++) {
			adjList[i] = new LinkList();
		}
		visitedV = new boolean[size];
	}

	// here we adding the edge of the graph
	public void addEdge(int start, int end) {
		if (start <= size && start >= 0 && end <= size && end >= 0) {
			adjList[start].insertEnd(end);
			adjList[end].insertEnd(start);
		} else {
			System.out.println("Error: Invalid Edge");
		}
	}

	// here we checking if the vertex has been visted or not
	public int visitedV(int data, boolean[] visitedV) {
		Node current = adjList[data].head;

		while (current != null) {
			if (visitedV[current.data] == true) {
				current = current.nextNode;
			} else {
				return current.data;
			}
		}
		return -1;

	}

	// here we do the traversing for our dfs
	public void dfs(int data) {
		LinkList dfs = new LinkList();

		Stack s = new Stack();
		s.push(data);
		System.out.println("Pushed " + data);

		dfs.insertEnd(data);

		visitedV[data] = true;

		int current = data;
		while (!s.isEmpty()) {
			current = visitedV(current, visitedV);

			// Found an unvisited neighbor
			if (current != -1) {
				s.push(current);
				System.out.println("Pushed " + current);

				dfs.insertEnd(current);

				visitedV[current] = true;
			}
			// No more unvisited neighbors
			else {
				System.out.println("Popped " + s.peek());
				s.pop();

				if (!s.isEmpty())
					current = s.peek();
			}
		}

		System.out.print("DFS: ");
		dfs.printList();

		// Call other method to check for disconnected graphs
		if (isUnvisitedV()) {
			disconnected();
		}
	}
// here we check unvisited neighbors 
	public boolean isUnvisitedV() {
		for (int i = 0; i < visitedV.length; i++) {
			if (visitedV[i] == false) {
				return true;
			}
		}
		return false;
	}
// method for the disconected graph  
	public void disconnected() {
		for (int i = 0; i < visitedV.length; i++) {
			if (visitedV[i] == false) {
				System.out.println("\nDisconnected Graph:");
				dfs(i);
				break;
			}
		}
	}
	
	
	

}
